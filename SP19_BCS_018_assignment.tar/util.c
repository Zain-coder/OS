#include <stdio.h>
#include <stdlib.h> 
 int readfromfile(int *a,char x[]) {

    FILE *fptr;
    int i=0;
    if ((fptr = fopen(x, "r")) == NULL) 
    {
        printf("Error! opening file");
        exit(1);
    }
    for(i=0;i<9;i++)
    {
    fscanf(fptr,"%d", a+i);
    }
    fclose(fptr);
    return 0;
}

