#include<stdio.h>
#include"simple.h"
#include<string.h>
int readfromfile(int *a,char x[]) ;
int main(int argc,char* argv[])
{
int memory[100];
int i=0;int exit;
int temp;
int instructregister;
int accumlator;
int counter=0;
int opcode;
int operand;
readfromfile(&memory[0],argv[1]);
do
{
for(i=0;i<25;i++)
{
    instructregister=memory[i];
    accumlator;
    counter++; 
    opcode=instructregister/100; 
    operand=instructregister%100;
    
    switch(opcode)
{    
    case read:
    {
    memory[opcode]=operand;
    printf("Value inserted at index %d\n",i);
    printf("accumlator:%d\n",accumlator);
    printf("Counter:%d\n",counter);
    printf("Operand: %d\n",operand);
    printf("Opcode: %d\n",opcode);
    
    break;
    }
    
    case write:
    {
    printf("Value at index %d=%d\n",opcode,operand);
    printf("accumlator:%d\n",accumlator);
    printf("Counter:%d\n",counter);
    printf("Operand: %d\n",operand);
    printf("Opcode: %d\n",opcode);
    break;
    }
    
    case load:
    {
    accumlator=operand;
    printf("Value inserted in Accumulator:%d\n",accumlator);
    printf("accumlator:%d\n",accumlator);
    printf("Counter:%d\n",counter);
    printf("Operand: %d\n",operand);
    printf("Opcode: %d\n",opcode);
    break;
    }
    
    case store:
    {
    memory[opcode]=accumlator;
    printf("value of accumlator stored!!!\n");
    printf("accumlator:%d\n",accumlator);
    printf("Counter:%d\n",counter);
    printf("Operand: %d\n",operand);
    printf("Opcode: %d\n",opcode);
    break;
    }
    
    case add:
    {
    accumlator=accumlator+operand;
    printf("Updated accumlator Value:%d\n",accumlator);
    printf("accumlator:%d\n",accumlator);
    printf("Counter:%d\n",counter);
    printf("Operand: %d\n",operand);
    printf("Opcode: %d\n",opcode);
    break;
    }
    
    case subtract:
    {
    accumlator=operand-accumlator;
    printf("updated accumulator after subtraction:%d\n",accumlator);
    printf("accumlator:%d\n",accumlator);
    printf("Counter:%d\n",counter);
    printf("Operand: %d\n",operand);
    printf("Opcode: %d\n",opcode);
    break;
    }
    
    case divide:
    {
    accumlator=accumlator/operand;
    printf("updated accumulator:%d\n",accumlator);
    printf("accumlator:%d\n",accumlator);
    printf("Counter:%d\n",counter);
    printf("Operand: %d\n",operand);
    printf("Opcode: %d\n",opcode);
    break;
    }

	
    case multiply:
    {
    accumlator=accumlator*operand;
    printf("updated accumulator:%d\n",accumlator);
    printf("accumlator:%d\n",accumlator);
    printf("Counter:%d\n",counter);
    printf("Operand: %d\n",operand);
    printf("Opcode: %d\n",opcode);
    break;
    }

	
    case branch:
    {
    temp=opcode;
    instructregister=memory[temp];
    printf("accumlator:%d\n",accumlator);
    printf("Counter:%d\n",counter);
    printf("Operand: %d\n",operand);
    printf("Opcode: %d\n",opcode);
    continue;
    break;
    }

	
    case branchneg:
    {
    if(accumlator<0)
    {
    temp=opcode;
    instructregister=memory[temp];
    continue;
    }
    break;
    }

	
    case branchzero:
    {
    if(accumlator==0)
    {
    temp=opcode;
    instructregister=memory[temp];
    continue;
    }
    break;
}

    case halt:
    {
    exit=43;
    printf("program halted\n");
    break;
    }  
    i++;
}
}
}
while(exit!=43);
}

