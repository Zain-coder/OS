import java.io.File; 
import java.io.FileNotFoundException; 
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.*;
public class LT2 implements Runnable{
   public int gdata[][];
   public int res[][];
   int v;int r;
   LT2(int data[][],int v,int r)
   {
       this.gdata=data;
       this.v=v;
       this.r=r;
   }
    public void setRes(int[][] res) {
      this.res = res;
  }

  @Override
public void run() {
  int i,j;
    for(i = 0; i < 4; ++i)
    {
          for(j = 0; j <4; ++j)
    {
        res[r][i]= res[r][i]+(gdata[r][j]*gdata[j][i]);
        //System.out.printf("%d+=%d*%d\n",res[r][i],gdata[r][j],gdata[j][i]);
    }
    //System.out.printf("%d\t",res[r][i]);
    }  
   // System.out.printf("\n");        
}
public static int readfromfile(int data[][]) throws FileNotFoundException
{
 File file=new File("input.txt");
   Scanner scan=new Scanner(file);
   int i = 0;
  int res=scan.nextInt();
  while(i<res)
  {
  for(int j=0;j<res;j++)
  {
  data[i][j] = scan.nextInt();
  }
  i++;
  }
  return res;
  
}
public static void main(String[] args) throws FileNotFoundException {
int data[][]=new int[4][4];
int i=0,j=0;
int st=readfromfile(data);
int res[][]=new int[st][st];
ExecutorService a=Executors.newFixedThreadPool(st);
while(i<st){
    LT2 t=new LT2(data,st,i);
    t.setRes(res);
    a.execute(t);
    i++;
}

a.shutdown();  
for(i=0;i<4;i++)
{
for(j=0;j<4;j++)
{
System.out.printf("%d\t",res[i][j]);
}
System.out.printf("\n");
}

}

}

 
  


